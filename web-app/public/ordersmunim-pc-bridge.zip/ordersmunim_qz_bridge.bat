@echo off
title OrdersMunim - Myntra Virtual QZ Tray Bridge
color 0b
cls
echo ===============================================================
echo       OrdersMunim - Myntra Virtual QZ Tray Desktop Bridge
echo       Auto PDF Downloader for Shipping Labels and Invoices
echo ===============================================================
echo.
echo Checking for Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on your system!
    echo Please install Node.js from https://nodejs.org or use the OrdersMunim Chrome Extension instead.
    echo.
    pause
    exit /b
)

echo [OK] Node.js detected. Starting OrdersMunim Virtual QZ Bridge...
echo.
node "%~dp0ordersmunim_qz_bridge.js"
echo.
pause
